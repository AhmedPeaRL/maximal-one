import json
import argparse
import numpy as np
import random
import os
import traceback
import hashlib
import analysis.hard_determinism_lock
from analysis.load_real_datasets import load_series
from analysis.numerical_spectral_verification import estimate_alpha
from analysis.fixed_precision import (
    recursively_freeze,
    freeze_float
)

def is_valid_segment(x):
    if np.std(x) < 1e-3:
        return False
    if np.max(x) - np.min(x) < 1e-2:
        return False
    return True

def generate_series(rng, n=1024):
    wn = rng.standard_normal(n)

    # 🔥 random walk
    rw = np.cumsum(rng.standard_normal(n))

    # 🔥 mix
    x = 0.7 * wn + 0.3 * np.diff(rw, prepend=rw[0])
    x[0] = 0.0
    fft = np.fft.rfft(x)
    phases = rng.uniform(0, 2*np.pi, len(fft))
    phases[0] = 0.0
    magnitudes = np.abs(fft)
    new_fft = np.abs(fft) * np.exp(1j * phases)
    x = np.fft.irfft(new_fft, n=n)

    return x

def stable_float(x, digits=8):
    return float(round(x, digits))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--canonical", action="store_true")
    parser.add_argument(
        "--output-dir",
        type=str,
        default="artifacts"
    )
    args = parser.parse_args()

    from pathlib import Path

    STRICT_CLAIM_PATH = Path(
        "core-scientific/strict_claim.json"
    )

    if not STRICT_CLAIM_PATH.exists():
        raise SystemExit(
            "❌ strict_claim.json missing"
        )

    with STRICT_CLAIM_PATH.open(
        "r",
        encoding="utf-8",
    ) as f:
        strict_claim = json.load(f)

    EXPECTED_MIN, EXPECTED_MAX = map(
        float,
        strict_claim["expected_result"]["alpha_range"]
    )

    MAX_METHOD_DELTA = float(
        strict_claim["expected_result"]["max_method_delta"]
    )

    MAX_SCALE_DISPERSION = float(
        strict_claim["expected_result"]["max_scale_dispersion"]
    )

    MAX_P_VALUE = float(
        strict_claim["expected_result"]["max_p_value"]
    )

    MIN_INDEPENDENT_SECONDARY_REAL_DOMAINS = int(
        strict_claim["expected_result"][
            "min_independent_secondary_real_domains"
        ]
    )

    PRIMARY_REAL_DOMAIN_REQUIRED = bool(
        strict_claim["expected_result"].get(
            "primary_real_domain_required",
            True,
        )
    )
    
    rng = np.random.default_rng(args.seed)
    np.random.seed(args.seed)  # 🔥 مهم جداً
    os.makedirs(args.output_dir, exist_ok=True)

    import subprocess
    import sys

    if args.canonical:
        prepare_script = Path(
            "scripts/prepare_canonical_inputs.py"
        )

        if not prepare_script.exists():
            raise SystemExit(
                "❌ Canonical input preparation script missing"
            )

        subprocess.run(
            [
                sys.executable,
                str(prepare_script),
            ],
            check=True,
        )

    # === ENSURE DATASET EXISTS (SELF-CONTAINED REPRODUCTION) ===
    if not os.path.exists("real-data/sunspots_full.csv"):
        raise SystemExit("❌ Base dataset missing — cannot proceed")
    
    PRIMARY_DATASET = (
        "real-data/sunspots_full.csv"
    )

    AUXILIARY_DATASET = (
        "real-data/sunspots_global_extended.csv"
    )

    if not os.path.exists(PRIMARY_DATASET):
        raise SystemExit(
            "❌ Primary dataset missing"
        )

    auxiliary_available = os.path.exists(
        AUXILIARY_DATASET
    )

    if auxiliary_available:
        print(
            "✅ Auxiliary dataset available"
        )
    else:
        print(
            "⚠️ Auxiliary dataset unavailable"
        )

    try:
        real = load_series(
            PRIMARY_DATASET
        )

        real = np.asarray(
            real,
            dtype=np.float64
        )

        real = real[
            np.isfinite(real)
        ]

        if len(real) < 256:
            raise SystemExit(
                f"❌ Primary dataset too short after canonical loading: {len(real)}"
            )

        if np.std(real) <= 1e-12:
            raise SystemExit(
                "❌ Primary dataset is degenerate after canonical loading"
            )
        
        real_bytes = np.ascontiguousarray(
            real,
            dtype=np.float64
        ).tobytes()

        real_sha256 = hashlib.sha256(
            real_bytes
        ).hexdigest()

        print(
            "Primary analysis length:",
            len(real)
        )

        print(
            "Primary analysis SHA256:",
            real_sha256
        )

        real_reference = real.copy()
        extended_reference = None

        import pandas as pd
        if auxiliary_available:
            ext_df = pd.read_csv(
                AUXILIARY_DATASET
            )

            if "Sunspots" in ext_df.columns:
                extended_reference = (
                    ext_df["Sunspots"]
                    .astype(np.float64)
                    .values
                )
        
        synthetic = generate_series(rng, n=len(real))

        if args.canonical:
            series = real.copy()
            
            generator_type = "real_primary_canonical"
        else:
            series = synthetic
            generator_type = "structured_chaotic_process"

        print("Real length:", len(real))
        print("Synthetic length:", len(synthetic))
        print("Series sample:", series[:5])

        from analysis.fixed_precision import freeze_float

        noise_samples = []
        base_series = series.copy()
        local_rng = np.random.default_rng(args.seed + 999)

        for i in range(10):
            local_series = base_series.copy()

            local_series = local_series - np.mean(local_series)
            local_series = local_series / (np.std(local_series) + 1e-12)

            wn = np.asarray(
                local_rng.normal(0, np.std(local_series), len(local_series)),
                dtype=np.float64
            )

            alpha_noise_sample = estimate_alpha(wn)

            alpha_noise_sample = freeze_float(
                alpha_noise_sample,
                digits=8
            )

            if alpha_noise_sample is not None and np.isfinite(alpha_noise_sample):
                noise_samples.append(alpha_noise_sample)

        # ✅ PURE MEASUREMENT MODE (NO DISTORTION)
        x = series.copy()
        
        if len(x) < 50:
            x = series.copy()
            
        x = x - np.mean(x)
        x = x / (np.std(x) + 1e-12)

        autocorr = np.correlate(x, x, mode='full')
        autocorr = autocorr[len(autocorr)//2:]
        ratio = np.percentile(autocorr[1:100], 95) / (autocorr[0] + 1e-12)

        # 🔥 allow natural periodicity but detect pathological lock-in
        if ratio > 0.985:
            print(f"⚠️ Strong periodic component detected (ratio={ratio:.3f})")

            # check diversity of signal
            unique_ratio = len(np.unique(np.round(x, 4))) / len(x)
            if unique_ratio < 0.005:
                raise SystemExit(
                    f"❌ Degenerate periodic lock (ratio={ratio:.3f}, diversity={unique_ratio:.4f})"
                )
        
        if len(series) < 256:
            raise SystemExit(
                f"❌ Canonical series too short; synthetic padding is forbidden: {len(series)}"
            )

        alpha = estimate_alpha(series)
        if not np.isfinite(alpha):
            raise SystemExit(
                "❌ Alpha estimation failed"
            )

        alpha = freeze_float(alpha, digits=8)
        if alpha is None:
            raise SystemExit("❌ alpha became None after freezing")

        if not isinstance(alpha, (int, float)) or not np.isfinite(alpha):
            raise SystemExit(f"❌ alpha invalid: {alpha}")

        if not (
            EXPECTED_MIN
            <= alpha
            <= EXPECTED_MAX
        ):
            raise SystemExit(
                f"❌ Alpha outside strict scientific range: {alpha}"
            )

        # ============================================================
        # HALF/FULL STABILITY DIAGNOSTIC
        # ============================================================
        #
        # The half/full comparison is retained as a scientific
        # stability diagnostic.
        #
        # It is NOT a hard falsification gate because the current
        # strict_claim.json does not preregister a half/full
        # disagreement threshold.
        #
        # The result must remain observable and must never be
        # silently corrected, clipped, or used to force agreement.
        # ============================================================

        x = np.asarray(
            series,
            dtype=np.float64
        )

        half = x[:len(x)//2]
        full = x

        a_half = estimate_alpha(half)
        a_full = estimate_alpha(full)

        if not (
            np.isfinite(a_half)
            and np.isfinite(a_full)
        ):
            raise SystemExit(
                "❌ Half/full alpha invalid"
            )

        half_full_delta = abs(
            float(a_full)
            -
            float(a_half)
        )

        half_full_stability = {
            "half_alpha": stable_float(
                a_half,
                8
            ),
            "full_alpha": stable_float(
                a_full,
                8
            ),
            "absolute_delta": stable_float(
                half_full_delta,
                8
            ),
            "status": (
                "elevated"
                if half_full_delta > 0.8
                else "within_diagnostic_range"
            ),
            "evidence_role": "diagnostic_only",
            "hard_gate": False,
            "interpretation": (
                "Half/full spectral estimates differ materially; "
                "this indicates temporal or estimator sensitivity "
                "and is retained for scientific inspection. "
                "It is not itself a falsification condition because "
                "no half/full threshold is preregistered in "
                "strict_claim.json."
                if half_full_delta > 0.8
                else
                "Half/full spectral estimates show no elevated "
                "diagnostic discrepancy."
            )
        }

        if half_full_delta > 0.8:
            print(
                "⚠️ Elevated half/full alpha discrepancy: "
                f"delta={half_full_delta:.8f}"
            )
            print(
                "ℹ️ Diagnostic only; no hard claim gate is applied."
            )
        else:
            print(
                "✅ Half/full alpha discrepancy within "
                "diagnostic range: "
                f"delta={half_full_delta:.8f}"
            )

        from analysis.integration_diagnostics import (
            integration_score,
            classify_process
        )

        integration_ratio = integration_score(series)
        process_class = classify_process(series)
    
        from analysis.falsification_tests import run_falsification
        from analysis.falsification_tests import temporal_direction_test
        from analysis.falsification_tests import phase_surrogate_guard
        from analysis.falsification_tests import validate as validate_bootstrap
        from analysis.numerical_spectral_verification import block_bootstrap
        from analysis.statistical_significance import monte_carlo_p_value
        from analysis.multi_scale_validation import evaluate_scale_invariance
        from analysis.cross_seed_validation import run as cross_seed_validation
        from analysis.evidence_fusion import (
            evidence_fusion
        )
        from analysis.consensus_guard import (
            consensus_check
        )
        from analysis.predictive_validation import (
            evaluate_prediction
        )
        from analysis.appropriate_stochastic_null import (
            parametric_short_memory_null,
        )

        falsification_rng = np.random.default_rng(args.seed + 101)
        direction_gap = temporal_direction_test(series)
        bootstrap_rng = np.random.default_rng(args.seed + 202)
        stats_rng = np.random.default_rng(args.seed + 303)
        stochastic_null_rng = np.random.default_rng(
            args.seed + 707
        )
        
        # ✅ minimal preprocessing only
        series = series.astype(np.float64)
        series = series - np.mean(series)

        prediction_validation = evaluate_prediction(series)

        # 🔥 scale without killing structure
        std = np.std(series)
        if std > 1e-6:
            series = series / std
        else:
            return SystemExit("❌ Degenerate signal")

        scale_test = evaluate_scale_invariance(series)

        # ============================================================
        # HARD CANONICAL ALPHA CONSISTENCY GATE
        # ============================================================

        canonical_alpha_for_scale = estimate_alpha(
            series,
            freq_min=0.01,
            freq_max=0.05,
        )

        if not np.isfinite(
            canonical_alpha_for_scale
        ):
            raise SystemExit(
                "❌ Canonical alpha unavailable for scale consistency"
            )

        if not scale_test.get(
            "valid",
            False
        ):
            raise SystemExit(
                "❌ Scale validation protocol invalid: "
                + str(
                    scale_test.get(
                        "reason",
                        "unknown_reason"
                    )
                )
            )

        scale_one_alpha = scale_test.get(
            "scale_one_alpha"
        )

        if scale_one_alpha is None:
            raise SystemExit(
                "❌ Scale validation did not produce scale=1 alpha"
            )

        scale_one_delta = abs(
            float(scale_one_alpha)
            -
            float(canonical_alpha_for_scale)
        )

        if scale_one_delta > 1e-8:
            raise SystemExit(
                "❌ INTERNAL SCIENTIFIC CONSISTENCY FAILURE: "
                "scale=1 alpha differs from canonical alpha: "
                f"delta={scale_one_delta:.12f}"
            )

        print(
            "✅ HARD CANONICAL ALPHA CONSISTENCY PASSED"
        )

        print(
            f"   canonical alpha: "
            f"{canonical_alpha_for_scale:.8f}"
        )

        print(
            f"   scale=1 alpha: "
            f"{float(scale_one_alpha):.8f}"
        )

        print(
            f"   delta: "
            f"{scale_one_delta:.12f}"
        )

        if not isinstance(scale_test, dict):
            raise SystemExit(
                "❌ Scale validation returned a non-dict result"
            )

        scale_dispersion = scale_test.get(
            "dispersion",
            scale_test.get(
                "relative_spread",
                np.nan
            )
        )

        if not np.isfinite(scale_dispersion):
            print(
                "⚠️ Scale dispersion unavailable."
            )
            print(
                "ℹ️ Downstream evidence will treat "
                "scale dispersion as invalid."
            )

        cross_seed = cross_seed_validation(
            series
        )
        
        if not cross_seed.get(
            "seed_stable",
            False
        ):
            raise SystemExit(
                "❌ Cross-seed instability detected"
            )

        falsification = recursively_freeze(
            run_falsification(
                series,
                falsification_rng
            )
        )

        phase_guard = phase_surrogate_guard(
            falsification["original_alpha"],
            falsification["phase_randomized_alpha"]
        )
        print(
            "Phase surrogate gap:",
            phase_guard["gap"]
        )
        print(
            "Phase interpretation:",
            phase_guard["interpretation"]
        )

        boot = recursively_freeze(
            block_bootstrap(
                series,
                bootstrap_rng
            )
        )
        print("BOOTSTRAP MEAN:", boot["mean"])
        print("BOOTSTRAP STD:", boot["std"])
        print("ALPHA:", alpha)

        bootstrap_guard = validate_bootstrap(
            alpha,
            boot["mean"],
            boot["std"]
        )
        bootstrap_bias_gap = abs(
            float(alpha) - float(boot["mean"])
        )

        bootstrap_bias_ratio = (
            bootstrap_bias_gap /
            (float(boot["std"]) + 1e-12)
        )

        bootstrap_center_discrepancy = {
            "absolute_gap": stable_float(
                bootstrap_bias_gap,
                8
            ),
            "std_units": stable_float(
                bootstrap_bias_ratio,
                8
            ),
            "flag": bool(
                bootstrap_bias_ratio > 2.0
            ),
            "interpretation": (
                "point estimate differs materially from the "
                "center of the block-bootstrap resampling distribution; "
                "this is a resampling-sensitivity diagnostic, "
                "not evidence of estimator bias"
                if bootstrap_bias_ratio > 2.0
                else
                "no large discrepancy between point estimate and "
                "block-bootstrap center"
            ),
            "evidence_role": "diagnostic_only"
        }
        
        if not bootstrap_guard["passed"]:
            raise SystemExit(
                "❌ Bootstrap consistency failed"
            )

        MAX_BOOTSTRAP_CENTER_SIGMA = float(
            strict_claim["expected_result"].get(
                "max_bootstrap_center_discrepancy_sigma",
                2.5,
            )
        )

        if bootstrap_bias_ratio > MAX_BOOTSTRAP_CENTER_SIGMA:
            raise SystemExit(
                "❌ Bootstrap center discrepancy exceeds "
                f"scientific tolerance: {bootstrap_bias_ratio:.8f} sigma "
                f"> {MAX_BOOTSTRAP_CENTER_SIGMA:.8f}"
            )

        if bootstrap_bias_ratio > 2.0:
            print(
                "⚠️ Bootstrap center discrepancy is elevated "
                f"({bootstrap_bias_ratio:.8f} sigma)"
            )
            print(
                "ℹ️ Result remains usable only as a diagnostic; "
                "scientific support is not strengthened by this metric."
            )

        stats = recursively_freeze(
            monte_carlo_p_value(
                series,
                alpha,
                stats_rng
            )
        )
        null_rejected = bool(
            stats["valid"]
            and
            stats["p_value"] <= 0.05
        )

        if not null_rejected:
            print(
                "⚠️ Permutation null NOT rejected."
            )
            print(
                "ℹ️ This result cannot be presented as statistically significant evidence."
            )
        else:
            print(
                "✅ Permutation null rejected at alpha=0.05."
            )
            print(
                "ℹ️ Interpretation: "
                "evidence against the specified exchangeability/permutation null only."
            )
            
        for key, value in falsification.items():
            if not np.isfinite(value):
                raise SystemExit(f"❌ Invalid falsification metric: {key}")

        if not scale_test.get("scale_invariant", False):
            print("⚠️ Scale invariance criterion not satisfied.")
            print("ℹ️ The result is retained for scientific evaluation.")
        else:
            print("✅ Scale invariance criterion satisfied.")
        
        if stats["p_value"] > 0.05:
            print("⚠️ Weak statistical signal — continuing with caution")

        if stats["p_value"] > 0.05:
            print(
                "⚠️ Null hypothesis not rejected"
            )

        stochastic_null = parametric_short_memory_null(
            series,
            alpha,
            stochastic_null_rng,
            trials=int(
                strict_claim[
                    "stochastic_null_protocol"
                ]["bootstrap_trials"]
            ),
        )

        stochastic_null_rejected = bool(
            stochastic_null.get("valid", False)
            and
            stochastic_null.get(
                "reject_at_0_05",
                False
            )
        )

        if stochastic_null_rejected:
            print(
                "✅ Appropriate stochastic "
                "short-memory null rejected."
            )
        else:
            print(
                "⚠️ Appropriate stochastic "
                "short-memory null NOT rejected."
            )
            print(
                "ℹ️ Scientific support remains closed."
            )

        from analysis.independent_validation import compare_methods

        method_comparison = compare_methods(series)

        if not isinstance(method_comparison, dict):
            raise SystemExit(
                "❌ Independent validation returned an unexpected object"
            )

        required_method_keys = {
            "welch_alpha",
            "fft_alpha",
            "delta",
            "finite",
            "agreement",
            "threshold",
        }

        missing_method_keys = (
            required_method_keys
            - set(method_comparison.keys())
        )

        if missing_method_keys:
            raise SystemExit(
                "❌ Independent validation missing required fields: "
                + ", ".join(sorted(missing_method_keys))
            )

        alpha_welch = float(
            method_comparison["welch_alpha"]
        )

        alpha_fft = float(
            method_comparison["fft_alpha"]
        )

        validation_delta = float(
            method_comparison["delta"]
        )

        if not np.isfinite(alpha_welch):
            raise SystemExit(
                "❌ Primary Welch alpha estimator failed"
            )

        if not np.isfinite(alpha_fft):
            raise SystemExit(
                "❌ Independent FFT alpha estimator failed"
            )

        if not np.isfinite(validation_delta):
            raise SystemExit(
                "❌ Independent validation delta is non-finite"
            )

        alpha = stable_float(
            alpha_welch,
            8
        )

        print(
            f"Primary Welch alpha: {alpha_welch}"
        )

        print(
            f"Independent FFT alpha: {alpha_fft}"
        )

        print(
            f"Agreement delta: {validation_delta}"
        )

        # 🔥 تنظيف صارم للـ noise samples
        clean_noise = [
            x for x in noise_samples
            if (x is not None and np.isfinite(x))
        ]

        if len(clean_noise) < 3:
            raise SystemExit("❌ insufficient valid noise samples")

        alpha_noise = stable_float(
            float(np.mean(clean_noise)),
            digits=8
        )

        alpha = stable_float(
            alpha,
            digits=8
        )

        if abs(alpha - alpha_noise) < 0.1:
            print("⚠️ Alpha too close to noise — weak structure")

        boot = {
            "mean": stable_float(boot["mean"], 8),
            "std": stable_float(boot["std"], 8),
            "ci_low": stable_float(boot["ci_low"], 8),
            "ci_high": stable_float(boot["ci_high"], 8)
        }

        stats = {
            k: (
                stable_float(v, 8)
                if isinstance(v, float)
                else v
            )
            for k, v in stats.items()
        }

        falsification = {
            k: stable_float(v, 8)
            for k, v in falsification.items()
        }

        from analysis.strong_null_model import (
            permutation_null,
        )
        from analysis.separation_test import (
            separation_score,
        )

        null_samples = []

        for _ in range(400):
            sample = permutation_null(
                series,
                stats_rng,
            )

            alpha_null = estimate_alpha(
                sample
            )

            if np.isfinite(alpha_null):
                null_samples.append(
                    sample
                )

        sep = separation_score(
            series,
            null_samples,
        )

        null_alpha_values = [
            estimate_alpha(s)
            for s in null_samples
        ]

        null_alpha_values = [
            x
            for x in null_alpha_values
            if np.isfinite(x)
        ]

        print(
            "NULL STD:",
            np.std(null_alpha_values)
            if null_alpha_values
            else np.nan,
        )

        print("=== SEPARATION ===")

        DIAGNOSTIC_SEPARATION_Z = 2.5
        required_z = DIAGNOSTIC_SEPARATION_Z

        if sep is None:
            print("SEP = None")
        else:
            for k, v in sep.items():
                print(
                    f"{k}: {v}"
                )

        separation_support = True
        separation_diagnostics = []

        if sep is None:
            separation_support = False
            separation_diagnostics.append(
                "separation_unavailable"
            )
            
        else:
            if not sep.get("z_score_valid", False):
                separation_support = False
                separation_diagnostics.append(
                    "null_scale_collapsed"
                )
            else:
                if sep["alpha_z_score"] < required_z:
                    separation_support = False
                    separation_diagnostics.append(
                        "separation_z_below_threshold"
                    )

            if sep["overlap_score"] > 0.95:
                separation_support = False
                separation_diagnostics.append(
                    "excessive_null_overlap"
                )

        print(
            "Separation support:",
            separation_support
        )

        print(
            "Separation diagnostics:",
            separation_diagnostics
        )

        if sep is not None:
            print(
                "Empirical separation p-value:",
                sep.get("empirical_p_upper")
            )

            print(
                "Null degenerate:",
                sep.get("null_degenerate", False)
            )

        falsification_delta = abs(
            falsification["original_alpha"]
            -
            falsification["white_noise_alpha"]
        )

        validation_delta = abs(
            alpha_fft
            -
            alpha_welch
        )

        scale_dispersion = scale_test.get(
            "dispersion",
            scale_test.get(
                "relative_spread",
                np.nan
            )
        )

        fusion = evidence_fusion(
            alpha_delta=abs(
                alpha - alpha_noise
            ),
            p_value=stats["p_value"],
            scale_dispersion=scale_dispersion,
            validation_delta=validation_delta,
            falsification_delta=falsification_delta
        )
        
        from pathlib import Path

        # ============================================================
        # CANONICAL CONSENSUS MUST BE RECOMPUTED IN THIS RUN
        # Never trust a stale artifact as scientific input.
        # ============================================================

        import subprocess
        import sys

        canonical_consensus_script = (
            Path("scripts/canonical_consensus.py")
        )

        if not canonical_consensus_script.exists():
            raise SystemExit(
                "❌ Canonical consensus script missing"
            )

        subprocess.run(
            [
                sys.executable,
                str(canonical_consensus_script),
            ],
            check=True,
        )

        canonical_consensus_path = Path(
            "artifacts/canonical_consensus.json"
        )

        if not canonical_consensus_path.exists():
            raise SystemExit(
                "❌ Canonical consensus artifact was not generated"
            )

        with canonical_consensus_path.open(
            "r",
            encoding="utf-8"
        ) as f:
            canonical_consensus = json.load(f)

        measurement_valid_real_domains = int(
            canonical_consensus.get(
                "measurement_valid_real_domains",
                canonical_consensus.get(
                    "valid_real_domains",
                    0
                )
            )
        )

        replication_eligible_real_domains = int(
            canonical_consensus.get(
                "replication_eligible_real_domains",
                0
            )
        )

        consensus = consensus_check(
            alpha_welch,
            alpha_fft,
            stats["p_value"],
            scale_dispersion,
            fusion["evidence_score"],
            independent_real_domains=replication_eligible_real_domains,
            max_method_delta=MAX_METHOD_DELTA,
            max_scale_dispersion=MAX_SCALE_DISPERSION,
            max_p_value=MAX_P_VALUE,
            min_independent_real_domains=(
                MIN_INDEPENDENT_SECONDARY_REAL_DOMAINS
            ),
        )

        # ============================================================
        # EXTERNAL REPLAY IS NOT AN INPUT TO THE CANONICAL REPORT
        # ============================================================
        #
        # The canonical scientific report MUST be generated solely
        # from the declared empirical pipeline and canonical inputs.
        #
        # It must never read a previously generated replay artifact,
        # because that would allow a prior verification result to
        # influence the report that is subsequently reproduced.
        #
        # External clean-checkout reproducibility is evaluated later
        # by analysis/true_independent_reproduction.py and consumed
        # separately by analysis/independent_verifier.py.
        #
        # Therefore:
        #
        #   canonical pipeline
        #          |
        #          v
        #   canonical_report.json
        #          |
        #          +----> independent clean-checkout reproduction
        #                         |
        #                         v
        #                 external replay attestation
        #
        # There is deliberately NO reverse arrow.
        # ============================================================

        external_replay_verified = False
        fingerprint_match = False

        # IMPORTANT:

        # Do not load artifacts/external_replay_verification.json here.

        # Any future implementation that reads prior replay evidence
        # inside canonical report generation violates the provenance
        # direction of the scientific pipeline.

        print(
            "ℹ️ External replay attestation is intentionally "
            "excluded from canonical report generation."
        )

        print(
            "ℹ️ Reproducibility evidence is evaluated "
            "by the independent verification layer."
        )

        adversarial_control_path = Path(
            "artifacts/adversarial_control.json"
        )
        adversarial_control_passed = False

        if adversarial_control_path.exists():
            try:
                with adversarial_control_path.open(
                    "r",
                    encoding="utf-8",
                ) as f:
                    adversarial_control = json.load(f)

                adversarial_control_passed = (
                    adversarial_control.get(
                        "passed",
                        False
                    )
                    is True
                )

            except Exception:
                adversarial_control_passed = False

        MAX_CROSS_DOMAIN_STD = float(
            strict_claim["expected_result"].get(
                "max_cross_domain_std",
                1.2,
            )
        )

        MAX_SIGMA = float(
            strict_claim["expected_result"]["max_sigma"]
        )

        MAX_BOOTSTRAP_CENTER_SIGMA = float(
            strict_claim["expected_result"].get(
                "max_bootstrap_center_discrepancy_sigma",
                2.5,
            )
        )

        canonical_alpha = float(alpha)

        alpha_range_passed = (
            EXPECTED_MIN
            <= canonical_alpha
            <= EXPECTED_MAX
        )

        sigma_passed = (
            np.isfinite(boot["std"])
            and
            float(boot["std"]) <= MAX_SIGMA
        )

        p_value_passed = (
            np.isfinite(stats["p_value"])
            and
            float(stats["p_value"]) <= MAX_P_VALUE
        )

        method_passed = (
            np.isfinite(validation_delta)
            and
            validation_delta <= MAX_METHOD_DELTA
        )

        scale_dispersion_passed = (
            np.isfinite(scale_dispersion)
            and
            float(scale_dispersion)
            <= MAX_SCALE_DISPERSION
        )

        bootstrap_center_passed = (
            np.isfinite(bootstrap_bias_ratio)
            and
            bootstrap_bias_ratio
            <= MAX_BOOTSTRAP_CENTER_SIGMA
        )

        real_domain_std = canonical_consensus.get(
            "real_domain_std"
        )

        cross_domain_passed = (
            real_domain_std is not None
            and
            np.isfinite(real_domain_std)
            and
            float(real_domain_std)
            <= MAX_CROSS_DOMAIN_STD
        )

        primary_real_domain = canonical_consensus.get(
            "primary_real_domain",
            {},
        )

        primary_real_domain_available = bool(
            primary_real_domain.get(
                "available",
                False,
                )
                and
                int(
                    primary_real_domain.get(
                    "count",
                    0,
                    )
                ) == 1
        )

        measurement_valid_secondary_domains = int(
            canonical_consensus.get(
                "independent_secondary_real_domains",
                {}
            ).get(
                "measurement_valid_count",
                canonical_consensus.get(
                    "measurement_valid_real_domains",
                    canonical_consensus.get(
                        "valid_real_domains",
                        0,
                    ),
                ),
            )
        )

        replication_eligible_real_domains = int(
            canonical_consensus.get(
                "replication_eligible_real_domains",
                0,
            )
        )

        independent_domains_passed = bool(
            (
                not PRIMARY_REAL_DOMAIN_REQUIRED
                or primary_real_domain_available
            )
            and
            replication_eligible_real_domains
            >= MIN_INDEPENDENT_SECONDARY_REAL_DOMAINS
        )

        canonical_identity_passed = (
            abs(
                float(alpha)
                -
                float(alpha_welch)
            )
            <= 1e-8
            and
            abs(
                float(alpha)
                -
                float(stats["observed_alpha"])
            )
            <= 1e-8
            and
            abs(
                float(alpha)
                -
                float(sep["real_alpha"])
            )
            <= 1e-8
            and
            abs(
                float(alpha)
                -
                float(scale_test["scale_one_alpha"])
            )
            <= 1e-8
        )

        appropriate_stochastic_null_passed = bool(
            stochastic_null.get(
                "valid",
                False,
            )
            and
            stochastic_null.get(
                "support_eligible",
                False,
            )
            and
            stochastic_null.get(
                "reject_at_0_05",
                False,
            )
        )

        claim_supported = bool(
            alpha_range_passed
            and sigma_passed
            and method_passed
            and bootstrap_center_passed
            and cross_domain_passed
            and independent_domains_passed
            and canonical_identity_passed
            and appropriate_stochastic_null_passed
            and external_replay_verified
            and fingerprint_match
            and adversarial_control_passed
        )

        claim_status = (
            "empirically_supported"
            if claim_supported
            else "under_investigation"
        )

        from analysis.sovereign_inference_engine import SovereignInferenceEngine

        engine = SovereignInferenceEngine()
        decision = engine.ingest(alpha, alpha_noise)
        decision["primary_estimator"] = "Welch_PSD"
        decision["independent_validator"] = "FFT_periodogram"
        decision["validation_delta"] = stable_float(
            validation_delta,
            8
        )

        if not fusion[
            "structure_detected"
        ]:
            print(
                "⚠️ Evidence fusion below diagnostic threshold."
            )
            print(
                "ℹ️ This is a diagnostic outcome, not a scientific failure."
            )
        else:
            print(
                "ℹ️ Evidence fusion diagnostic threshold reached."
            )

        if not consensus["passed"]:
            print(
                "⚠️ Consensus guard did not pass:",
                consensus["diagnostics"]
            )
            print(
                "ℹ️ Scientific claim remains under investigation."
            )
        else:
            print(
                "✅ Consensus guard passed."
            )

        print(
            "Consensus diagnostics:",
            consensus["diagnostics"]
        )
        print(
            "Evidence score:",
            fusion["evidence_score"]
        )
        print(
            "P-value:",
            stats["p_value"]
        )
        print(
            "Dispersion:",
            scale_dispersion
        )

        report = {
            "predictive_validation": prediction_validation,
            "evidence_fusion": fusion,
            "phase_surrogate_guard": phase_guard,
            "bootstrap_consistency_guard": bootstrap_guard,
            "bootstrap_center_discrepancy": bootstrap_center_discrepancy,
            "spectral_profile": {
                "alpha_provenance": {
                    "source": "primary_estimator",
                    "estimator": "Welch_PSD",
                    "frequency_band": [
                        0.01,
                        0.05
                    ],
                    "nperseg": 1024,
                    "posthoc_correction": False,
                    "clipping": False,
                    "interpolation": False,
                    "synthetic_padding": False
                },
                "estimated_alpha": alpha,
                "bootstrap_mean": boot["mean"],
                "bootstrap_std": boot["std"],
                "falsification_tests": falsification,
                "ci_low": boot["ci_low"],
                "ci_high": boot["ci_high"],
                "noise_alpha": alpha_noise
            },
            "dataset_audit": {
                "analysis_length": int(len(real)),
                "analysis_sha256": real_sha256,
                "primary_dataset":
                    "sunspots_full",
                "primary_length":
                    int(len(real_reference)),
                "auxiliary_available":
                    bool(
                        extended_reference
                        is not None
                    ),
                "auxiliary_length":
                    int(
                        len(extended_reference)
                    )
                    if extended_reference
                    is not None
                    else 0
            },
            "metadata": {
                "seed": args.seed,
                "generator": generator_type
            },
            "integration_diagnostics": {
                "integration_ratio": stable_float(
                    integration_ratio,
                    8
                ),
                "process_class": process_class
            },
            "statistical_test": stats,
            "separation_support": {
                "supported": bool(separation_support),
                "required_z": float(required_z),
                "observed_z": (
                    float(sep["alpha_z_score"])
                    if (
                        sep is not None
                        and sep.get("z_score_valid", False)
                        and sep.get("alpha_z_score") is not None
                        and np.isfinite(sep["alpha_z_score"])
                    )
                    else None
                ),
                "z_score_valid": bool(
                    sep is not None
                    and sep.get("z_score_valid", False)
                    and sep.get("alpha_z_score") is not None
                    and np.isfinite(sep["alpha_z_score"])
                ),
                "diagnostic_empirical_p_upper": (
                    float(sep["empirical_p_upper"])
                    if (
                        sep is not None
                        and sep.get("empirical_p_upper") is not None
                        and np.isfinite(
                            sep["empirical_p_upper"]
                        )
                    )
                    else None
                ),
                "null_degenerate": bool(
                    sep is not None
                    and sep.get("null_degenerate", False)
                ),
                "diagnostics": separation_diagnostics,
            },
            "separation_test": sep,
            "permutation_null_rejected_diagnostic_only": bool(
                null_rejected
            ),
            "appropriate_stochastic_null":
                stochastic_null,
            "multi_scale_validation": scale_test,
            "perturbation_stability": cross_seed,
            "cross_method_validation": {
                "primary_method": "Welch_PSD",
                "validation_method": "FFT_periodogram",
                "fft_alpha": stable_float(alpha_fft),
                "welch_alpha": stable_float(alpha_welch),
                "agreement_delta": stable_float(validation_delta),
                "validated": bool(
                    validation_delta <= 0.30
                )
            },
            "cross_domain_replication": {
                "primary_real_domain_available": bool(
                    primary_real_domain_available
                ),
                "measurement_valid_secondary_real_domains": int(
                    measurement_valid_secondary_domains
                ),
                "replication_eligible_secondary_real_domains": int(
                    replication_eligible_real_domains
                ),
                "minimum_required_secondary": int(
                    MIN_INDEPENDENT_SECONDARY_REAL_DOMAINS
                ),
                "measurement_validity_is_not_replication": True,
                "domain_level_null_rejection_required": True,
                "scientific_replication_established_here": False,
                "scientific_replication_requires_independent_domain_null_rejection": True,
                "real_domain_std": (
                    float(real_domain_std)
                    if real_domain_std is not None
                    and np.isfinite(real_domain_std)
                    else None
                ),
                "passed": bool(
                    replication_eligible_real_domains
                    >= MIN_INDEPENDENT_SECONDARY_REAL_DOMAINS
                ),
            },
            "scientific_interpretation": {
                "permutation_null_rejected_diagnostic_only": bool(
                    null_rejected
                ),
                "appropriate_stochastic_null_rejected": bool(
                    stochastic_null_rejected
                ),
                "permutation_null_is_primary": False,
                "permutation_null_rejected":
                    bool(
                        null_rejected
                    ),
                "permutation_null_role": "diagnostic_only",
                "evidence_strength": (
                    "strong_for_specified_spectral_hypothesis"
                    if claim_supported
                    else "insufficient"
                ),
                "claim_status": claim_status,
                "reproducibility": {
                    "perturbation_stability": (
                        "passed"
                        if cross_seed.get("seed_stable", False)
                        else "failed"
                    ),
                    "independent_rerun": (
                        "verified"
                        if external_replay_verified
                        else "not_verified"
                    ),
                    "fingerprint_match": bool(
                        fingerprint_match
                    ),
                    "interpretation": (
                        "Independent rerun and fingerprint "
                        "verification are required for final "
                        "reproducibility support."
                    )
                },
                "claim_support_gate": bool(
                    claim_supported
                ),
            },
            "consensus_guard": consensus,
            "sovereign_layer": {
                "decision": decision,
                "engine_summary": engine.summary(
                    alpha,
                    alpha_noise
                )
            }
        }

        gap1 = abs(falsification["original_alpha"] - falsification["shuffled_alpha"])
        gap2 = abs(falsification["original_alpha"] - falsification["white_noise_alpha"])

        adaptive_gap = max(
            0.20,
            0.15 * alpha
        )

        if gap1 < adaptive_gap * 0.7:
            print("⚠️ Weak shuffle gap — tolerated")
       
        if gap2 < adaptive_gap * 0.7:
            print("⚠️ Weak noise separation — tolerated")
    
        gap_noise = abs(falsification["original_alpha"] - falsification["white_noise_alpha"])
        gap_shuffle = abs(falsification["original_alpha"] - falsification["shuffled_alpha"])

        if gap_noise < 0.10:
            print(
                "⚠️ Weak noise separation diagnostic:",
                float(gap_noise),
            )

        if gap_shuffle < 0.10:
            print(
                "⚠️ Weak shuffle separation diagnostic:",
                float(gap_shuffle),
            )
    
        if direction_gap < 0.005:
            print("⚠️ Weak temporal directionality — tolerated")

        method_delta = validation_delta

        if not np.isfinite(method_delta):
            raise SystemExit(
                "❌ Independent validation unavailable"
            )

        if method_delta > MAX_METHOD_DELTA:
             raise SystemExit(  
                 "❌ Method inconsistency too high"  
             )  

        if (
            method_delta
            >
            0.75 * MAX_METHOD_DELTA
        ):
            print(
                "⚠️ Method inconsistency approaching "
                "the canonical threshold"
            )
    
        output_path = os.path.join(
            args.output_dir,
            "canonical_report.json"
        )

        from analysis.canonical_json import write_canonical
        
        report = recursively_freeze(report)
        report = json.loads(
            json.dumps(
                report,
                sort_keys=True,
                separators=(",", ":")
            )
        )

        write_canonical(
            output_path,
            report
        )

        # ============================================================
        # FINAL CANONICAL SCIENTIFIC CONSISTENCY GATE
        # ============================================================

        validation_script = Path(
            "scripts/validate_canonical_report.py"
        )

        if not validation_script.exists():
            raise SystemExit(
                "❌ Canonical report validator missing"
            )

        subprocess.run(
            [
                sys.executable,
                str(validation_script),
            ],
            check=True,
        )

        print(
            "✅ Canonical report generated and internally validated"
        )
            
        print("✅ Spectral report generated (stable & reproducible)")

    except Exception as e:
        print("❌ CRITICAL FAILURE in generate_report")
        print(str(e))
        print(traceback.format_exc())
        raise SystemExit(1)

if __name__ == "__main__":
    main()
